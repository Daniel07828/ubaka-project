<?php
session_start();
if(isset($_POST['send_payment'])){
	$phoneNumber = $_POST['phone_number'];
	$amount = $_POST['amount'];
	$total_amount = $_SESSION['total_amount'];
	if(empty($phoneNumber)){
		echo "Please enter phone number";
	}
	elseif(empty($amount)){
		echo "Please enter amount to pay";
	}
	elseif($amount < 100){
		echo "Please enter amount not less than 100 Rwf";
	}
	elseif($amount < $total_amount){
		echo "Amount entered does not mutch with total amount your suposed to pay!";
	}
	
	else{
		/*{
    "code": "200",
    "description": "MERCHANT REGISTERED SUCCESSFULLY. CHECK YOUR EMAIL FOR YOUR CREDETIALS, NOTE THAT YOU WILL BE ASKED TO CHANGE THEM AT FIRST SIGNIN",
    "body": {
        "contactTelephoneNumber": "250780466434",
        "merchantId": "8a7481b26a6e64fb016adbc4231b0005",
        "contactEmail": "josephercoder@gmai.com",
        "contactName": "johson Nzayisenga",
        "businessName": "ubakaneza",
        "shortCode": "10309"
    }*/
		$orgId = "8a7481b26a6e64fb016adbc4231b0005";
		$transId =  rand();
		echo "Phone: ".$phoneNumber."<br>";
		echo "Amount: ".$amount;
		//header('Content-Type: application/json');
		$url = 'https://opay-api.oltranz.com/opay/paymentrequest';
		$data = array(
		'telephoneNumber' => $phoneNumber,
		'amount' => $amount,
		'organizationId' => $orgId,
		'description' => "payment",
		'callbackUrl' => "http://ubakaneza/payment/callbock",	
		'transaction' => $transId
		);
		
		echo "<br>".$data['telephoneNumber']."<br>";
		echo "<br>".$data['amount']."<br>";
		echo "<br>".$data['organizationId']."<br>";
		echo "<br>".$data['description']."<br>";
		echo "<br>".$data['transaction']."<br>";
		
		/*$postvars = http_build_query($fields);
		$ch = curl_init();
		
		curl_setopt($ch, CURLOPT_HTTPHEADER, 
					array('Content-Type: application/json')
				   );
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, count($fields));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $postvars);
		
		$result = curl_exec($ch);
		
		echo $result;
		
		curl_close($ch); */
		

$options = array(
        'http' => array(
        'header'  => "Content-type: application/json\r\n",
        'method'  => 'POST',
        'content' => json_encode($data),
    )
);

$context  = stream_context_create($options);
$result = file_get_contents( $url, false, $context );
$response = json_decode( $result );
		//$_SESSION['response'] = $response; 
		echo "Result = ".json_encode($response);
        $result = json_encode($response);
        $json = json_decode($result, true);
$_SESSION['code'] = $json['code'];
$_SESSION['description'] = $json['description'];
$_SESSION['status'] = $json['status'];

        header("Location: ../payment/payment.php");
		//echo $response['description'];
	}
}
?>