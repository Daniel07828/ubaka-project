<?php session_start(); ?>
<!DOCTYPE html>
<html dir="ltr" lang="en">
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/font-awesome/css/font-awesome.min.css" />
    <!-- CSS Files -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/now-ui-kit.css?v=1.1.0" rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="../assets/css/demo.css" rel="stylesheet" />

    <!--     inserted     -->
    <link rel="stylesheet" href="../plugins/datatables/dataTables.bootstrap.css">
    <link href="../assets/js/google-code-prettify/prettify.css" rel="stylesheet"/>
    <link href="../assets/css/bootstrap-responsive.css" rel="stylesheet"/>
    
    <link href="assets/style.css" rel="stylesheet"/>
    <!--     inserted     -->

</head>
<body>
<div id="container">
<header id="header" class="navbar navbar-static-top">
  <div class="container-fluid">

  
    <div id="header-logo" class="navbar-header"><a href="#" class="navbar-brand"><img src="view/image/logo.png" alt="MD GROU" title="MD GROU" /></a></div>
    <a href="#" id="button-menu" class="hidden-md hidden-lg"><span class="fa fa-bars"></span></a> </div>
</header>

<div id="content">
  <div class="container"><br />
    <br />
    <div class="row">
        <div class="col-md-3"></div>
     
	<div class="col-md-6 col-sm-4">
        <div class="panel panel-default">

          <div class="panel-heading">
            <h3 class="panel-title"><i class="fa fa-lock"></i> Please enter your payment details.</h3>
          </div>
          <div class="panel-body">
  <form action="send_payment.php" method="post" enctype="multipart/form-data">
              <div class="form-group">
                <label for="input-username">Phone Number</label>
                <div class="input-group"><span class="input-group-addon"><i class="fa fa-phone"></i></span>
                  <input type="text" name="phone_number" class="form-control">
                </div>
              </div>
             <div class="form-group">
                <label for="input-username">Amount/Rwf</label>
                <div class="input-group"><span class="input-group-addon"><i class="fa fa-money"></i></span>
                  <input type="number" name="amount" placeholder="Amount" id="amount" class="form-control" />
                </div>
              </div>

              <div class="text-right">
                <button type="submit" class="btn btn-primary" name="send_payment"><i class="fa fa-key"></i> Send</button>
              </div>
  </form>
          </div>
        </div>
      </div>
        <div class="col-md-3"><?php if(isset($_SESSION['code'])){ echo $_SESSION['code']."<br>"; 
            echo $_SESSION['description']."<br>";
            echo $_SESSION['status'];
                                                               }?></div>
    </div>
  </div>
</div>
<footer id="footer"><a href="#">Goup 9</a> &copy; 2019 All Rights Reserved.<br /></footer></div>
</body></html>
