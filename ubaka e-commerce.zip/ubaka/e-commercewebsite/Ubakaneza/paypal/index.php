<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel='stylesheet' href='../assets/css/bootstrap.min.css' type='text/css' media='all' />
    <title>Paypal Integration Test</title>
</head>
<body>
<div class="container">
	<div class="row">
    <div class="col-md-2"></div>
<div class="col-md-8">
    <div class="card">
    <h2 class="card-header">Praduct detail</h2>
    <div class="card-body">

    <form class="paypal" action="payments.php" method="post" id="paypal_form" >
        <input type="hidden" name="cmd" value="_xclick" />
        <input type="hidden" name="no_note" value="1" />
        <input type="hidden" name="lc" value="UK" />
        <input type="hidden" name="bn" value="PP-BuyNowBF:btn_buynow_LG.gif:NonHostedGuest" />
		             <div class="form-group">
						 <label class="control-label" for="input-email">First Name </label>
        <input type="text" name="first_name" value="<?php echo $_SESSION['username']; ?>" class="form-control" />
			</div>

         <div class="form-group">
						 <label class="control-label" for="input-email"> Pro Name</label>
        <input type="text" name="payer_email" value="<?php if(isset($_SESSION['prod_name'])){ echo $_SESSION['prod_name'];} ?>" class="form-control"/>
		</div>

				             <div class="form-group">
						 <label class="control-label" for="input-email"> Quantity</label>
        <input type="text" name="payer_email" value="<?php if(isset($_SESSION['quantity'])){ echo $_SESSION['quantity'];} ?>" class="form-control"/>
		</div>
				             <div class="form-group">
						 <label class="control-label" for="input-email">Price </label>
        <input type="text" name="item_number" value="<?php if(isset($_SESSION['price'])){  echo $_SESSION['price']; } ?>" class="form-control" / >
		</div>
				             <div class="form-group">
						 <label class="control-label" for="input-email">Total price </label>
        <input type="text" name="amount" value="<?php if(isset($_SESSION['amount'])){  echo  $_SESSION['amount'];} ?>" class="form-control"/>
		</div>
        <div class="form-group">
            <a href="../index.php">Back</a>
					
            <button type="submit" name="submit" value="Pay" class="btn btn-sm btn-success" style="float: right;">Pay</button>
		</div>
    </form>
    </div>
    </div>
		</div>
	<div class="col-md-2">
	</div>
	</div>
	</div>

</body>
</html>
